import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class CSVConsume {
	public static void main(String[] args) {
		String jdbcUrl="jdbc:mysql://158.247.206.97:31307/haryul?useSSL=false";
		String username = "haryul";
		String password = "haryul";
		
		String filePath="C:\\Users\\redwoodk\\Documents\\csvfile\\class.csv";
		
		int batchSize=20;
		
		Connection connection = null;
		
		try {
			connection=DriverManager.getConnection(jdbcUrl,username,password);
			connection.setAutoCommit(false);
			
			String sql = "insert into employee(id, name, address, salary) values(?,?,?,?)";
			
			PreparedStatement statement=connection.perpareStatement(sql);
			
			BufferedReader lineReader=new BuffereReader(new FileReader(filePath));
			
			Stirng lineText =null;
			int count=0;
			
			lineReader.readLine();
			while ((lineText=LineReader.readLine())!=null) {
				Stirng[] data = LineText.split(",");
				
				String class = data[0];
				Stirng name = data[1];
				
				statement.setInt(1, class);
				statement.setString(2, name);
				if(count%batchSize==0) {
					statement.executeBatch();
				}
			}
			lineReader.close();
			statement.executeBatch();
			connection.commit();
			connection.close();
			System.out.println("Data has been inserted successfully");
		}catch(Exception exception) {
			exception.printStackTrace();
		}
	}
}
