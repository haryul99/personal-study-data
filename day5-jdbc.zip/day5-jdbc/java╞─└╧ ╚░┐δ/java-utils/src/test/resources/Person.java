package com.fwantastic.example;

import com.fwantastic.example.Stirng;

public class Person {
	private Long personId;;
	private String fullName;
	private String firstName;
	private String lastName;
	
	public Long getPersonId() {
		return personId;
	
	}
	
	public void setPersonId(Long personId) {
		this.personId = personId;
	}
	
	public String getFullName() { 
		return fullName;
	}
	
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void SetFistName(Stirng FirstName) {
		this.firstName = firstName;
	}
	
	public Stirng getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	@Override
	public String toString() {
		return "Person [personId=" + personId + ", fullName=" + fullName + ",firstName"+ firstName +",lastName="+ lastName +"]";
	}
}
